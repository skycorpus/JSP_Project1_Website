package JSon.controller.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JSon.dao.JSonDAO;
import JSon.dto.JSonVO;

public class JSBoardListAction implements Action {

	public void execute(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		String url = "/JiSikON/JSonboardList.jsp";
		
		JSonDAO jVao = JSonDAO.getInstance();
		
		List<JSonVO> JsonboardList = jVao.selectAllJSons();
		
		request.setAttribute("JSonboardList", JsonboardList);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}
}

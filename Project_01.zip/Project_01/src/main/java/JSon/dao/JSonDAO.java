// 참고한거 623p 책, 그 영화 커뮤니티 어쩌고

package JSon.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import JSon.dto.JSonVO;

import util.DBManager;

public class JSonDAO {
	private JSonDAO() {
	}
	
private static JSonDAO instance = new JSonDAO();

public static JSonDAO getInstance() {
	return instance;
}

public List<JSonVO> selectAllJSons() {
	String sql = "select * from json order by num desc";
	
	List<JSonVO> list = new ArrayList<JSonVO>();
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	
	try {
		conn = DBManager.getConnetction();
		stmt = conn.createStatement();
		
		rs = stmt.executeQuery(sql);
		
		while (rs.next()) {
			JSonVO jVo = new JSonVO();
			
			jVo.setNum(rs.getInt("num"));
			jVo.setTitle(rs.getString("title"));
			jVo.setId(rs.getString("id"));
			jVo.setNickname(rs.getString("nickname"));
			jVo.setRegdate(rs.getString("regdate"));
			jVo.setContent(rs.getString("content"));
			jVo.setGood(rs.getInt("good"));
			jVo.setReadcount(rs.getInt("readcount"));
			
			list.add(jVo);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBManager.close(conn, stmt, rs);
	}
	return list;
}

public void insertJSon(JSonVO jVo) {
	String sql = "insert into json("
			+ "num, tilte, id, nickname, redgate, content, good, readcount)"
			+ "values(JSonBoard_num.NEXTVAL, ?, ?, ?, sysdate, default, default)";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	try {
		conn = DBManager.getConnetction();
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, jVo.getTitle());
		pstmt.setString(2, jVo.getId());
		pstmt.setString(3, jVo.getNickname());
		
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBManager.close(conn, pstmt);
	}
}

public void updateReadCount(String num) {
	String sql = "update json set readcount = readcount+1 where num=?";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	try {
		conn = DBManager.getConnetction();
		
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, num);
		
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBManager.close(conn, pstmt);
	}
}
	
// 게시판 글 상세 내용 보기 : 글번호로 찾아온다. : 실패 null,
public JSonVO selectOneJSonByNum(String num) {
	String sql = "select * from json where num = ?";
	
	JSonVO jVo = null;
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	try {
		conn = DBManager.getConnetction();
		
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, num);
		
		rs = pstmt.executeQuery();
		
		if(rs.next()) {
			jVo = new JSonVO();
			
			jVo.setNum(rs.getInt("num"));
			jVo.setTitle(rs.getString("title"));
			jVo.setId(rs.getString("id"));
			jVo.setNickname(rs.getString("nickname"));
			jVo.setRegdate(rs.getString("regdate"));
			jVo.setContent(rs.getString("content"));
			jVo.setGood(rs.getInt("good"));
			jVo.setReadcount(rs.getInt("readcount"));
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		DBManager.close(conn, pstmt, rs);
	}
	return jVo;
}

public void updateJSon(JSonVO jVo) {
	String sql = "update json set id=?, nickname=?, "
			+ "title=?, content=? where num=?";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	try {
		conn = DBManager.getConnetction();
		
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, jVo.getId());
		pstmt.setString(2, jVo.getNickname());
		pstmt.setString(3, jVo.getTitle());
		pstmt.setString(4, jVo.getContent());
		pstmt.setInt(5, jVo.getNum());
		
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBManager.close(conn, pstmt);
	}
}

public JSonVO checkPassWord(String pass, String num) {
	String sql = "select * from board where pass=? and num=?";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	JSonVO jVo = null;
	try {
		conn = DBManager.getConnetction();
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, pass);
		pstmt.setString(2, num);
		
		rs = pstmt.executeQuery();
		
		if(rs.next()) {
			jVo = new JSonVO();
			
			jVo.setNum(rs.getInt("num"));
			jVo.setTitle(rs.getString("title"));
			jVo.setId(rs.getString("id"));
			jVo.setNickname(rs.getString("nickname"));
			jVo.setRegdate(rs.getString("regdate"));
			jVo.setContent(rs.getString("content"));
			jVo.setGood(rs.getInt("good"));
			jVo.setReadcount(rs.getInt("readcount"));
		//	jVo.setPass(rs.getString("pass"));
		}
	} catch (SQLException e) {
		e.printStackTrace();
	} 
	return jVo;
	}


public void deleteJSon(String num) {
	String sql = "delete json where num=?";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	try {
		conn = DBManager.getConnetction();
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, num);
		
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}

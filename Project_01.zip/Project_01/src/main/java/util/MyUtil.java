package util;

public class MyUtil {
	// 전체 페이지
	public int getPageCount(int seqPerPage, int dataCount) {
		int pageCount = 0;
		
		pageCount = dataCount / seqPerPage;
		
		if(dataCount % seqPerPage != 0) {
			pageCount++;
		}
		return pageCount;
	}
	
	// 페이지 처리 메서드
	//currentPage : 현재 표시할 페이지, totalPage : 전체 페이지 수
	// listUrl : 링크를 설정할 Url(JSonBoard.jsp)
	public String pageIndexList(int currentPage, int totalPage, String listUrl) {
		int seqPerBlock = 5; //표시할 페이지 이전 6 7 8 9 10 다음 => 이거 이야기하는 거임
		int currentPageSetup; // 이전 다음에 들어있는 값. 표시할 첫 페이지의 -1해준 값
		int page; // 6 7 8 9 10 => 하이퍼링크가 될 page index 숫자
		
		StringBuffer sb = new StringBuffer();
	
		//데이터가 없을 때
		if(currentPage == 0 || totalPage == 0) {
			return ""; //null값 반환
	}
		
		//list.jsp?pageSeq=2
		//list.jsp?searchKey=title&searchValue=aa&pageSeq=2
		if(listUrl.indexOf("?")!= -1) {
			listUrl = listUrl + "&";
		} else {
			listUrl = listUrl + "?";
		}
		
		// 1 2 3 4 5 다음
		// 이전 6 7 8 9 10 다음
		// 이전 11 12 13 14 15 다음
		currentPageSetup = (currentPage / seqPerBlock) * seqPerBlock;
		
		if(currentPage % seqPerBlock == 0) {
			currentPageSetup = currentPageSetup - seqPerBlock;
		}
		
		// <=이전
		if(totalPage > seqPerBlock && currentPageSetup>0) {
			sb.append("<a href=\""+ listUrl + "pageSeq="+ currentPageSetup + "\">◀이전</a>&nbsp;");
			// a href = "JSonBoard.jsp?pageSeq=5> ◀이전</a>
		}
		
		// 바로 가기 페이지( 6 7 8 9 10)
		page = currentPageSetup + 1;
		
		while (page <= totalPage && page <= (currentPageSetup + seqPerBlock)) {
			if (page == currentPage) {
				sb.append("<font color=\"Fuchsia\">" + page + "</font>&nbsp;");
				//<font color = "Fuchsia">9</font>
			} else {
				sb.append("<a href=\"" + listUrl + "pageSeq=" + page + "\">" + page + "</a>&nbsp;");
				//<a href = "JSonBoard.jsp?pageSeq=7">7</a>&nbsp;
			}
			
			page++;
		}

		// 다음
		// 이전 6 7 8 9 10 다음
		// 이전 11 12
		if (totalPage - currentPageSetup> seqPerBlock) {
			sb.append("<a href=\"" + listUrl + "pageSeq=" + page + "\">다음▶</a>&nbsp;");
			// a href = "JSonBoard.jsp?pageSeq11;> 다음▶</a>&nbsp;
		}
		return sb.toString();
	}
}